num1 = float(input())
num2 = float(input())
num3 = float(input())
num4 = float(input())

avg = (num1 + num2 + num3 + num4)/4 
prod = num1 * num2 * num3 * num4
print(f'{prod:.0f} {avg:.0f}')
print(f'{prod:.3f} {avg:.3f}')
