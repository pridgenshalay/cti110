miles = float(input())
gas = float(input())
per_mile = gas / miles
twenty_miles = per_mile * 20
seventy_mile = per_mile * 75
fivehund_mile = per_mile * 500

print(f'{twenty_miles:.2f} {seventy_mile:.2f} {fivehund_mile:.2f}')
